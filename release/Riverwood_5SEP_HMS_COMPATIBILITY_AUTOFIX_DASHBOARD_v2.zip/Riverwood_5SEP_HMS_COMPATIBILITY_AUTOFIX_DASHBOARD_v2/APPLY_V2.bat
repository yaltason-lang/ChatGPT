@echo off
setlocal
cd /d "%~dp0"
py -3 installer.py --apply %*
if errorlevel 1 (
  echo.
  echo INSTALL FAILED
  pause
  exit /b 1
)
echo.
echo INSTALL OK
pause
