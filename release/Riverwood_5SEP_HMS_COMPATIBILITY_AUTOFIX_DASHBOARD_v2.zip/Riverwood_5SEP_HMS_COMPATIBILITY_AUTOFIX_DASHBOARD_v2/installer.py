from __future__ import annotations
import argparse, hashlib, os, shutil, sys, tempfile
from datetime import datetime
from pathlib import Path

MARKER = 'RIVERWOOD_HMS_COMPAT_AUTOFIX_V2'
UI_MARKER = 'RIVERWOOD_HMS_COMPAT_AUTOFIX_V2_UI'
HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / 'payload'


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def ignored(p: Path) -> bool:
    low = str(p).lower()
    return any(x in low for x in ('\\.git\\', '/.git/', '\\backup', '/backup', '\\dist\\', '/dist/', '\\payload\\', '/payload/'))

def roots(explicit):
    out=[]
    for raw in explicit or []:
        p=Path(raw).expanduser()
        if p.exists(): out.append(p.resolve())
    env=os.environ.get('RIVERWOOD_OPERATIONS_ROOT','').strip()
    if env and Path(env).exists(): out.append(Path(env).resolve())
    cwd=Path.cwd().resolve(); out.extend([cwd, *list(cwd.parents)[:3]])
    for raw in (r'C:\Riverwood', r'C:\RiverwoodOperations', r'C:\Riverwood_Operations', r'C:\Apps', r'D:\Riverwood', r'D:\RiverwoodOperations'):
        p=Path(raw)
        if p.exists(): out.append(p.resolve())
    seen=[]
    for p in out:
        if p not in seen: seen.append(p)
    return seen

def find_pairs(search_roots):
    pairs=[]; seen=set()
    for root in search_roots:
        try:
            modules=list(root.rglob('accommodation_module.py'))
        except Exception:
            continue
        for mod in modules:
            try: mod=mod.resolve()
            except Exception: continue
            if ignored(mod) or mod in seen: continue
            candidates=[mod.parent/'templates'/'accommodation_quote_detail.html', mod.parent/'accommodation_quote_detail.html']
            tpl=next((x.resolve() for x in candidates if x.exists() and not ignored(x)), None)
            if tpl is None:
                try:
                    matches=[x.resolve() for x in mod.parent.rglob('accommodation_quote_detail.html') if not ignored(x)]
                    tpl=matches[0] if len(matches)==1 else None
                except Exception: tpl=None
            if tpl is None: continue
            seen.add(mod)
            score=0
            for hint in ('app.py','wsgi.py','main.py'):
                if (mod.parent/hint).exists(): score+=4
            if (mod.parent/'templates').exists(): score+=4
            if (mod.parent/'data').exists(): score+=2
            if 'riverwood' in str(mod.parent).lower(): score+=3
            pairs.append((score, mod, tpl))
    pairs.sort(key=lambda x:(-x[0], str(x[1])))
    return pairs

def atomic_copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=dst.name+'.', suffix='.tmp', dir=str(dst.parent)); os.close(fd)
    try:
        shutil.copy2(src,tmp); os.replace(tmp,dst)
    finally:
        try: Path(tmp).unlink(missing_ok=True)
        except Exception: pass

def main():
    ap=argparse.ArgumentParser(description='Riverwood HMS compatibility autofix dashboard v2 replace-only installer')
    ap.add_argument('--root', action='append', help='Optional Riverwood Operations root; can be repeated')
    ap.add_argument('--apply', action='store_true', help='Actually replace live files. Without this flag only discovery is performed.')
    args=ap.parse_args()
    pairs=find_pairs(roots(args.root))
    if not pairs:
        print('FAILED: live accommodation_module.py + accommodation_quote_detail.html pair not found'); return 2
    top_score=pairs[0][0]; top=[x for x in pairs if x[0]==top_score]
    if len(top)!=1:
        print('FAILED: ambiguous live paths; use --root to point at the active Operations folder')
        for s,m,t in pairs[:10]: print(f'  score={s} module={m} template={t}')
        return 3
    _,mod,tpl=top[0]
    print('LIVE MODULE  :',mod); print('LIVE TEMPLATE:',tpl)
    if not args.apply:
        print('DRY RUN OK. Re-run with --apply to replace exactly these files.'); return 0
    src_mod=PAYLOAD/'accommodation_module.py'; src_tpl=PAYLOAD/'accommodation_quote_detail.html'
    if not src_mod.exists() or not src_tpl.exists(): print('FAILED: payload missing'); return 4
    if MARKER not in src_mod.read_text(encoding='utf-8') or UI_MARKER not in src_tpl.read_text(encoding='utf-8'):
        print('FAILED: package marker missing'); return 5
    before_mod=sha(mod); before_tpl=sha(tpl); expected_mod=sha(src_mod); expected_tpl=sha(src_tpl)
    if before_mod==expected_mod or before_tpl==expected_tpl:
        print('FAILED: at least one live file already equals payload; installer requires both live files to change'); return 6
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S'); backup=mod.parent/f'_riverwood_backup_hms_compat_v2_{stamp}'; backup.mkdir(parents=True, exist_ok=False)
    shutil.copy2(mod, backup/'accommodation_module.py'); shutil.copy2(tpl, backup/'accommodation_quote_detail.html')
    try:
        atomic_copy(src_mod,mod); atomic_copy(src_tpl,tpl)
        after_mod=sha(mod); after_tpl=sha(tpl)
        if after_mod==before_mod or after_tpl==before_tpl: raise RuntimeError('live files did not change')
        if after_mod!=expected_mod or after_tpl!=expected_tpl: raise RuntimeError('post-APPLY hash mismatch')
        if MARKER not in mod.read_text(encoding='utf-8'): raise RuntimeError('module marker not found after APPLY')
        html=tpl.read_text(encoding='utf-8')
        if UI_MARKER not in html or 'HMS-сумісність розміщення' not in html or 'Виправити автоматично' not in html: raise RuntimeError('new UI marker not found after APPLY')
    except Exception as exc:
        shutil.copy2(backup/'accommodation_module.py',mod); shutil.copy2(backup/'accommodation_quote_detail.html',tpl)
        print('FAILED:',exc,'; rollback restored'); return 7
    print('APPLY OK'); print('BACKUP:',backup); print('MODULE SHA256:',after_mod); print('TEMPLATE SHA256:',after_tpl)
    print('No :8082/:8085 lifecycle action was performed.')
    return 0
if __name__=='__main__': raise SystemExit(main())
