Riverwood HMS Compatibility Autofix Dashboard v2
==================================================

Scope
- Replaces ONLY accommodation_module.py and accommodation_quote_detail.html.
- Does NOT modify/start/stop/reconfigure :8082 or :8085.
- Does NOT modify pms_booking_adapter_v1.py, GroupCard or ReserveGroup 1/2/3.

What v2 adds
- Dashboard-side HMS composition compatibility analysis before live preflight.
- Visible “HMS-сумісність розміщення” block with exact physical room, nights and composition segments.
- Hard server-side and UI block for live preflight/HMS booking while a conflict remains.
- “Виправити автоматично” live autofix preview using other physical rooms of the same RoomType.
- Autofix preserves nightly adults/children/paid children/extra beds, capacity, live availability and adjacent-night early/late requirements.
- Explicit preview “було → стане”.
- Explicit save as a new immutable quote revision.
- Immediate HMS compatibility check after manual room preview/change.

Install
1. Copy/extract the package on the Operations Windows host.
2. Optional discovery only: py -3 installer.py
3. Apply: APPLY_V2.bat
4. Installer prints the exact live module/template paths before replacing them, creates a timestamped backup, verifies both hashes changed and verifies the new UI marker after APPLY.
5. If discovery is ambiguous, run: py -3 installer.py --root "C:\path\to\active\Riverwood" --apply

Fail-closed
Installer returns FAILED and rolls back if the active pair cannot be identified, either live file does not change, hashes differ after copy, or the v2 UI marker is absent.
