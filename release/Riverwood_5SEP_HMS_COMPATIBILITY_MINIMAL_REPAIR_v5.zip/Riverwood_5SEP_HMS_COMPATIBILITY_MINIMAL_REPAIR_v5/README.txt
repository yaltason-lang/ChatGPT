Riverwood HMS Compatibility Minimal Repair v5
=============================================

WHY v5
- v4 could detect 11 writer stays / 9 room slots but its autofix demanded a FULL live-options perfect matching for every row of a night.
- Production showed this was too strict: a 7-row RoomType/signature group failed even though only the conflicting subset needs to move.
- v5 treats the room IDs already selected on the night as valid permutation candidates and searches for the assignment that MINIMIZES writer stay starts across the previous/current/next night boundary.

WHAT CHANGES
- Detection and hard block remain exactly as in v3/v4.
- Autofix no longer requires every currently selected RoomID to be present in the live "free options" list just to keep/swap it inside the same already-selected night set.
- Existing selected RoomIDs are always available as permutation candidates; genuinely new RoomIDs are allowed only when returned by live availability.
- Assignment is optimized per RoomType against BOTH previous-night and next-night continuity.
- Already-continuous rows are preserved unless moving them produces a strictly better total writer-stay result.
- Final candidate day still goes through the existing live manual recalculation path, which revalidates the exact final room set, capacity, rates, restrictions and early/late rules.
- If no RoomID-only repair can reduce the writer-stay count enough, nothing is saved and the error explains that the nightly signature multiset itself requires a deeper reallocation rather than pretending another free room will solve it.

INSTALL
1. Extract ZIP on Operations host.
2. Run APPLY_V5.bat.
3. Restart ONLY Operations :8080.
4. Open ACC-20260829-002 and press “Виправити автоматично · minimal repair”.

NOT TOUCHED
- :8082
- :8085
- pms_booking_adapter_v1.py
- GroupCard
- ReserveGroup 1/2/3
