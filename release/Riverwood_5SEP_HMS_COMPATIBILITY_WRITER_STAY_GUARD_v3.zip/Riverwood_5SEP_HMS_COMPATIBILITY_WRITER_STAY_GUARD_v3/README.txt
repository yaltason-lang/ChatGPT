Riverwood HMS Compatibility Writer-Stay Guard v3
=================================================

WHY v3
- v2 guarded only one narrow pattern: the same RoomID changing composition on adjacent nights.
- The 05.09 production failure proved the real writer invariant is broader: the dashboard must predict the exact 8085 writer room_stays count before HMS.
- Example from ACC-20260829-002: maximum simultaneous rooms = 9, writer generated stay 10/11 and HMS stopped at 9 GuestIDs. v3 blocks this before live preflight.

WHAT v3 DOES
- Mirrors the writer stay signature exactly: (RoomTypeID, adults, children, paid_children, extra_beds).
- Mirrors contiguous-room merge/gap behavior exactly.
- Computes writer_stays_count and the current room-slot budget BEFORE any HMS preflight/write.
- HARD BLOCKS live preflight and HMS booking when writer_stays_count > room-slot budget.
- Shows “HMS-сумісність розміщення” ALWAYS, including a green OK state with exact counts.
- On BLOCKED state shows exact physical rooms, stay segments, nights and compositions that create extra writer stays.
- “Виправити автоматично” attempts a continuity-aware physical-room remap, preserving nightly adults/children/paid children/extra beds, RoomType/capacity, live availability and early/late availability.
- Autofix is fail-closed: if physical-room reassignment cannot reduce writer stays enough without changing the per-room guest composition, nothing is saved and booking remains blocked.
- Successful autofix is previewed “було → стане” and saved only as a new quote revision.
- Manual room preview immediately recalculates writer-stay compatibility.

INSTALL
1. Extract this ZIP on the Operations Windows host.
2. Run APPLY_V3.bat.
3. Restart ONLY the Operations :8080 process the same way you normally restart it.
4. Open the quote. A visible HMS compatibility card MUST appear even when status is OK.

CONFIRMED ROOT / PATH SAFETY
- The installer prefers C:\Riverwood_Operations_MVP0_Core_Employees in exact-root mode when present.
- Generic discovery excludes All versions, _backups, before_*, baseline*, dist, payload and .git.
- Installer backs up and atomically replaces ONLY accommodation_module.py and templates\accommodation_quote_detail.html.

NOT TOUCHED
- :8082
- :8085
- pms_booking_adapter_v1.py
- pms_sidecar_with_room_quote_v3.py
- GroupCard writer logic
- ReserveGroup 1/2/3
