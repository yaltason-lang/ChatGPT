Riverwood Operations live-source capture ANYPORT V2
===================================================
READ ONLY. This tool does not modify, stop, start, or restart any process, service, port, tunnel, configuration, or source file.

It does NOT assume Operations listens on :8080.
It inventories listening ports and Python/app processes, reports sanitized Cloudflared ingress hints, and copies every non-historical accommodation_module.py candidate plus its quote-detail template into one capture ZIP.

Run CAPTURE_LIVE_OPERATIONS_ANYPORT_V2.bat on the Windows host serving staging.
After CAPTURE OK, upload the generated CAPTURED_LIVE_OPERATIONS_ANYPORT_V2.zip to ChatGPT.
