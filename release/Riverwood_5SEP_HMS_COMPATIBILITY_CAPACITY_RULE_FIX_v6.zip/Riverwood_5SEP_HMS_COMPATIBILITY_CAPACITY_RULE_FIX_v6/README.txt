Riverwood HMS Compatibility Capacity Rule Fix v6
===============================================

WHY v6
- v5 production error: “Не вдалося знайти жодного допустимого призначення RoomType 2 для 7 рядків цієї ночі.”
- The matcher incorrectly compared all occupants only with base/capacity_per_room and rejected a valid Standard Double row with 3 adults + 1 extra bed when base capacity is 2 and extra capacity is 1.
- That made every candidate disappear before the continuity optimizer could even try the 111<->112 repair.

WHAT v6 CHANGES
- Candidate capacity validation now follows the real room rule: occupants may use base capacity plus the explicitly requested extra beds, provided requested extra beds do not exceed extra_capacity.
- Example now valid: base=2, extra_capacity=1, adults=3, extra_beds=1.
- A row with adults=3 and extra_beds=0 remains invalid for base=2.
- A row requesting extra_beds=2 remains invalid when extra_capacity=1.
- v3 writer-stay detection, v5 minimal continuity optimizer and all HMS hard blocks remain.
- Final proposed plan still passes through the existing live manual recalculation before preview/save.

INSTALL
1. Extract ZIP on the Operations host.
2. Run APPLY_V6.bat.
3. Restart ONLY Operations :8080.
4. Open ACC-20260829-002 and press “Виправити автоматично · capacity-aware repair”.

NOT TOUCHED
- :8082
- :8085
- pms_booking_adapter_v1.py
- GroupCard
- ReserveGroup 1/2/3
