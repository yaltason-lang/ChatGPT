Riverwood HMS Compatibility Swap Autofix v4
============================================

WHY v4
- v3 correctly detects the writer-stay overflow before HMS (for ACC-20260829-002: 11 stays / 9 room slots).
- v3 autofix was still too greedy: it preserved already-continuous rooms first and then searched for an additional unused live room.
- On a fully allocated night that can fail even when a safe solution exists by SWAPPING/PERMUTING the physical RoomIDs already selected in the quote.

WHAT v4 CHANGES
- Detection/hard block from v3 remains.
- Autofix now performs a whole-night continuity matching, not row-by-row greedy replacement.
- It can swap/permutate already selected physical rooms among rows of the same RoomType when that preserves writer continuity.
- It does NOT require a 10th spare room for a 9-room night.
- Per-row adults/children/paid_children/extra_beds remain unchanged.
- Candidate RoomID must still be live available and pass RoomType/capacity/extra-bed/early/late checks.
- Every changed night is still run through the existing live manual recalculation path before preview/save.
- If no full safe permutation exists, nothing is saved and preflight/booking remain blocked.

INSTALL
1. Extract ZIP on the Operations host.
2. Run APPLY_V4.bat.
3. Restart ONLY Operations :8080 in the normal way.
4. Open ACC-20260829-002 and press “Виправити автоматично”.
5. Expected: a “було → стане” preview using swaps/permutations of the existing room set where possible.

NOT TOUCHED
- :8082
- :8085
- pms_booking_adapter_v1.py
- GroupCard
- ReserveGroup 1/2/3
