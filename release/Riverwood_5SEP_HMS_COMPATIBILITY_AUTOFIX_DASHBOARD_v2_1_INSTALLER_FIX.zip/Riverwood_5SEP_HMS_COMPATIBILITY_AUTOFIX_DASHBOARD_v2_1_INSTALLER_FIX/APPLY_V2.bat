@echo off
setlocal
cd /d "%~dp0"
if exist "C:\Riverwood_Operations_MVP0_Core_Employees\accommodation_module.py" if exist "C:\Riverwood_Operations_MVP0_Core_Employees\templates\accommodation_quote_detail.html" (
  echo Using confirmed Operations root: C:\Riverwood_Operations_MVP0_Core_Employees
  py -3 installer.py --root "C:\Riverwood_Operations_MVP0_Core_Employees" --exact-root --apply
) else (
  py -3 installer.py --apply %*
)
if errorlevel 1 (
  echo.
  echo INSTALL FAILED
  pause
  exit /b 1
)
echo.
echo INSTALL OK
pause
