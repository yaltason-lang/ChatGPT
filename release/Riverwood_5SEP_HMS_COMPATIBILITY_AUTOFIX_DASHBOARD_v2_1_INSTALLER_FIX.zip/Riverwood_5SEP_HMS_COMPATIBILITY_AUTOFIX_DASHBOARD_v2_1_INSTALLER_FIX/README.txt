Riverwood HMS Compatibility Autofix Dashboard v2.1 — installer-path hotfix
=======================================================================

Why v2.1 exists
- v2 correctly failed closed, but its recursive discovery gave the same score to the active Operations root and an archived copy under “All versions”.
- v2.1 fixes ONLY installer path selection; the verified HMS compatibility/autofix payload is unchanged.

Confirmed Operations root for this deployment
C:\Riverwood_Operations_MVP0_Core_Employees

APPLY_V2.bat behavior
- If the confirmed root exists, it uses that root in exact-root mode and does NOT recurse into “All versions” or backups.
- Generic discovery ignores All versions, _backups, before_*, baseline*, dist, payload and .git paths.
- It refuses to APPLY to a historical/archive/backup path.
- It backs up the two live files, atomically replaces them, then verifies exact payload hashes and UI/module markers.

Scope remains unchanged
- Replaces ONLY accommodation_module.py and templates\accommodation_quote_detail.html.
- Does NOT modify/start/stop/reconfigure :8082 or :8085.
- Does NOT modify pms_booking_adapter_v1.py, GroupCard or ReserveGroup 1/2/3.
