﻿Riverwood LIVE :8080 Operations capture V1
===========================================
READ ONLY. Does not modify, stop, start, or restart any service or source file.

Run CAPTURE_LIVE_8080_OPERATIONS_V1.bat on the host where Operations :8080 is listening.
After CAPTURE OK, send CAPTURE_REPORT.txt and LIVE_8080_accommodation_module.py from CAPTURED_LIVE_8080_OPERATIONS to ChatGPT.
